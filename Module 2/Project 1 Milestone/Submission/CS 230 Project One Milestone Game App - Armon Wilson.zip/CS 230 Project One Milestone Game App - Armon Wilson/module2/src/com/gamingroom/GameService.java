package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
//ADDED CODE: Iterator utility 
import java.util.Iterator;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */

/*
 * Additions made by:
 * Armon Wilson
 * SNHU CS-230 Operating Systems
 * 1/20/2024
 */

/*
 * SINGLETON PATTERN EXPLANATION:
 * 
 * This design pattern revolves around a class that can create an object
 * while ensuring that only a single instance is instantiated. This class 
 * offers a method to access its exclusive object directly, eliminating the 
 * need to instantiate multiple instances of the class to access it.  * 
 *
 *
 * ITERATOR PATTERN EXPLANATION:
 * The Iterator pattern in the code simplifies the process of going through
 * the list of active games to find a game with a specific name. It abstracts
 * away the details of how the iteration is done, making the code more straightforward.
 * The loop checks each game's name, and when a match is found, the loop exits,
 * and the matching game is assigned to the game variable. 
 * This pattern improves code clarity and separates the iteration logic from the
 * main search functionality.
 */


public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	// FIXED: Add missing pieces to turn this class a singleton 
	
	//ADDED CODE
	private static GameService instance;
	// ^^ Create instance variable
	
	// ADDED CODE
    private GameService() {
    // ^^ private constructor to prevent instantiation
    }
    
    //ADDED CODE
    /* 
     * Method to further implement "Singleton Pattern"
     * Ensures only one instance of the "GameService" class 
     * is created and the same instance is returned when called.
     */
    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }
	
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;
		
		// FIXED: Use iterator to look for existing game with same name
		// if found, simply return the existing instance
		// if not found, make a new game instance and add to list of games
		
		
		//ADDED CODE
		
		//Iterates through the game list to check for already existing game. 
		//If no existing game found, it is added to the list. 
		 Iterator<Game> iterator = games.iterator();
	     while (iterator.hasNext()) {
	    	 Game existingGame = iterator.next();
	    	 if (existingGame.getName().equals(name)) {
	    		 game = existingGame;
	    		 break;
	         }
	     }
			        
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	public Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;
		

		// FIXED: Use iterator to look for existing game with same id
		// if found, simply assign that instance to the local variable
		
		//ADDED CODE
		/*
		 * Iterates through the games list to look for existing gameId.
		 * If found, local game variable changed to the found game within the list
		 * and is returned. 
		 */
		Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game existingGame = iterator.next();
            if (existingGame.getId() == id) {
                game = existingGame;
                break;
            }
        }
        return game;
	}
		
	

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// FIXED: Use iterator to look for existing game with same name
		// if found, simply assign that instance to the local variable

		//ADDED CODE
		/*
		 * Iterates through the "games" list to check if "name" parameter 
		 * already exists. Sets the local game variable to the existing game 
		 * if found, the returns the variable.  
		 */
		Iterator<Game> iterator = games.iterator();
		while(iterator.hasNext()) {
			Game existingGame = iterator.next();
			if (existingGame.getName().equals(name)){
				game = existingGame;
				break;
			}
		}

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
